import cv2
from deepface import DeepFace
import threading
import numpy as np
import time

# Cargar el clasificador pre-entrenado
clasificador_cara = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Capturar video desde la cámara con una resolución reducida
captura = cv2.VideoCapture(0)
captura.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
captura.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# Almacenar resultados previos
resultados_previos = []
tiempo_ultimo_analisis = time.time()
intervalo_analisis = 2  # Intervalo en segundos para realizar nuevos análisis

# Función para analizar la cara y devolver resultados
def analizar_cara(imagen_cara, resultados):
    try:
        # Analizar edad y emoción
        resultado = DeepFace.analyze(imagen_cara, actions=['age', 'emotion'], enforce_detection=False)
        if isinstance(resultado, list) and len(resultado) > 0:
            resultado = resultado[0]
        edad = resultado.get('age', 'N/A')
        emocion = resultado.get('dominant_emotion', 'N/A')
        resultados.append((edad, emocion))
    except Exception as e:
        print(f"Error al analizar la cara: {e}")
        resultados.append(('N/A', 'N/A'))

while True:
    # Capturar frame por frame
    ret, frame = captura.read()

    # Reducir la resolución del frame para mejorar el rendimiento
    frame_pequeno = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)

    # Convertir a escala de grises
    gris = cv2.cvtColor(frame_pequeno, cv2.COLOR_BGR2GRAY)

    # Detección de caras
    caras = clasificador_cara.detectMultiScale(gris, 1.1, 4)

    # Verificar si ha pasado suficiente tiempo desde el último análisis
    tiempo_actual = time.time()
    if tiempo_actual - tiempo_ultimo_analisis >= intervalo_analisis:
        tiempo_ultimo_analisis = tiempo_actual

        # Resultados del análisis
        resultados = []

        # Dibujar rectángulos alrededor de las caras detectadas y estimar características
        hilos = []
        for (x, y, w, h) in caras:
            # Ajustar coordenadas a la resolución original
            x, y, w, h = [v * 2 for v in (x, y, w, h)]
            
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            
            # Recortar la cara detectada
            imagen_cara = frame[y:y+h, x:x+w]
            
            # Crear un hilo para analizar la cara
            hilo = threading.Thread(target=analizar_cara, args=(imagen_cara, resultados))
            hilos.append(hilo)
            hilo.start()

        # Esperar a que todos los hilos terminen
        for hilo in hilos:
            hilo.join()

        # Almacenar resultados previos
        resultados_previos = resultados.copy()
    else:
        # Dibujar rectángulos sin volver a analizar
        for (x, y, w, h) in caras:
            # Ajustar coordenadas a la resolución original
            x, y, w, h = [v * 2 for v in (x, y, w, h)]
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

    # Mostrar los resultados en el frame
    for i, (x, y, w, h) in enumerate(caras):
        x, y, w, h = [v * 2 for v in (x, y, w, h)]
        if i < len(resultados_previos):
            edad, emocion = resultados_previos[i]
            cv2.putText(frame, f'Edad: {edad}', (x, y-30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(frame, f'Emoción: {emocion}', (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2, cv2.LINE_AA)

    # Mostrar el frame resultante
    cv2.imshow('Detección de caras', frame)

    # Salir del loop si se presiona 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Liberar el objeto de captura y cerrar todas las ventanas
captura.release()
cv2.destroyAllWindows()
